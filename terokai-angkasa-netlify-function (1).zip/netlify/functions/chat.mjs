const SYSTEM_PROMPT = `Anda ialah Rakan ChatBot AI untuk laman Terokai Angkasa Kita, pembelajaran Bahasa Melayu Tahun 6.
Jawab dalam Bahasa Melayu yang jelas, mesra dan sesuai untuk murid Tahun 6. Gunakan bahan RPH sebagai konteks utama: DSKP SK 2.2, SP 2.2.1, buku cerita digital Impian Adam ke Angkasa, AR 3D, Model ASSURE, rumusan, isi penting, ramalan dan tugasan Bakawali, Sakura serta Akasia.
Anda juga boleh menjawab soalan pengetahuan umum di luar bahan pembelajaran, termasuk soalan sains dan kerjaya seperti pekerjaan angkasawan. Bezakan penjelasan daripada bahan RPH dengan pengetahuan umum apabila sesuai. Untuk fakta yang mungkin berubah mengikut masa, nyatakan bahawa murid perlu menyemak sumber terkini atau bertanya kepada guru.
Untuk tugasan sekolah, beri petunjuk dan galakkan penaakulan sebelum memberikan contoh jawapan. Jangan minta nama penuh, kata laluan, alamat atau maklumat peribadi. Jangan beri kandungan berbahaya atau tidak sesuai umur. Jika tidak pasti, katakan dengan jujur dan cadangkan sumber atau bantuan guru.`;

const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' } });

export default async (request) => {
  if (request.method === 'OPTIONS') return json({}, 204);
  if (request.method !== 'POST') return json({ error: 'Kaedah tidak disokong.' }, 405);
  if (!process.env.OPENAI_API_KEY) return json({ error: 'OPENAI_API_KEY belum dikonfigurasikan di Netlify.' }, 503);

  let body;
  try { body = await request.json(); } catch { return json({ error: 'Format soalan tidak sah.' }, 400); }
  const message = String(body?.message || '').trim();
  if (!message) return json({ error: 'Sila tulis soalan.' }, 400);
  if (message.length > 1500) return json({ error: 'Soalan terlalu panjang.' }, 413);

  const history = Array.isArray(body?.history) ? body.history.slice(-8).filter(item => ['user', 'assistant'].includes(item?.role)).map(item => ({ role: item.role, content: String(item.content || '').slice(0, 2000) })) : [];
  const baseUrl = (process.env.OPENAI_API_BASE || 'https://api.openai.com/v1').replace(/\/$/, '');
  const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
  const upstream = await fetch(`${baseUrl}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, body: JSON.stringify({ model, messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...history], temperature: 0.4, max_tokens: 500 }) });
  const data = await upstream.json().catch(() => ({}));
  if (!upstream.ok) return json({ error: data?.error?.message || 'Model AI tidak dapat menjawab sekarang.' }, 502);
  const reply = data?.choices?.[0]?.message?.content?.trim();
  if (!reply) return json({ error: 'Model AI memulangkan jawapan kosong.' }, 502);
  return json({ reply });
};
