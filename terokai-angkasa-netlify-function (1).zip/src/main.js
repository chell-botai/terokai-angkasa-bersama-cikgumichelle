import './style.css';

const app = document.querySelector('#app');

const state = {
  section: 'home',
  activeGroup: 'bakawali',
  explorer: 'bulan',
  quizIndex: 0,
  score: 0,
  videoStep: 0,
  videoAnswered: false,
  groupResponses: {},
  promptResponses: {},
  answered: false,
  selectedAnswer: null,
  checklist: {},
  exitSaved: false,
  toast: '',
  menuOpen: false,
  chatOpen: false,
  chatBusy: false,
  chatMessages: [{ role: 'assistant', content: 'Hai! Saya Rakan ChatBot AI. Tanya saya tentang angkasa, tugasan RPH atau apa-apa soalan umum yang sesuai untuk pembelajaran.' }]
};

const navItems = [
  { id: 'home', label: 'Utama', eyebrow: 'MULA DI SINI' },
  { id: 'metadata', label: 'DSKP & RPH', eyebrow: 'PENGENALAN' },
  { id: 'assure', label: 'Model ASSURE', eyebrow: 'RANGKA PdP' },
  { id: 'segment1', label: 'Set Induksi', eyebrow: 'CETUS IDEA' },
  { id: 'segment2', label: 'Langkah 1–3', eyebrow: 'TEROKA & ANALISIS' },
  { id: 'assessment', label: 'Penilaian', eyebrow: 'BUKTI BELAJAR' },
  { id: 'game', label: 'Permainan', eyebrow: 'KAHOOT / WORDWALL' },
  { id: 'closing', label: 'Penutup', eyebrow: 'EXIT TICKET' },
  { id: 'guidance', label: 'Panduan', eyebrow: 'PERANAN GURU/MURID' }
];

const materialLinks = {
  canvaLyrics: 'https://canva.link/90hycvd1p',
  youtube: 'https://youtu.be/Gb5FbB49rXY?si=zGxRG_MDkmu4HT_a',
  fliphtml5: 'https://online.fliphtml5.com/lfgfji/BUKU-IMPIAN-ADAM-KE-ANGKASA-kxTM/',
  assemblr: 'https://assemblredu-h4kw6ffu.manus.space/',
  ideaflip: 'https://ideaflip.com/edit/ggbbyrhxtqf5/yOYCnyw6WqNX',
  ideaflipAlt: 'https://ideaflip.com/edit/kgk8j7ky8c23/akQjjfeJToNX',
  canvaMap: 'https://canva.link/l04uq647iokffd1',
  canvaCards: 'https://canva.link/wx06orl9bp3dgml',
  docs: 'https://docs.google.com/document/d/1xjhR2s5MSzIW5gGLx-nhywcsDI3E7t52rVVaHPfgDsg/edit?usp=sharing',
  gemini: 'https://gemini.google.com/app',
  wordwall: 'https://wordwall.net/resource/120958333?wwmethod=link',
  kahoot: 'https://create.kahoot.it/share/latihan-pengukuhan-tahun-6-dahlia/5f5ee385-d2c1-4969-8617-03fbf6a0c6bf',
  forms: 'https://forms.gle/dXoQ5tYesBezJbpD7'
};

const conceptPrinciples = [
  ['Multimedia', 'Teks, grafik, audio, video dan animasi digabungkan untuk membantu murid membina gambaran mental tentang angkasa.'],
  ['Coherence', 'Paparan kekal ringkas: hanya kata kunci, ilustrasi utama dan arahan yang diperlukan pada satu masa.'],
  ['Signaling', 'Warna kumpulan, nombor checkpoint, bar kemajuan dan label tag mengarahkan perhatian kepada perkara penting.'],
  ['Redundancy', 'Audio tidak mengulang semua teks skrin; ia melengkapkan visual supaya murid tidak dibebani maklumat berlebihan.'],
  ['Segmenting', 'Cerita dibahagi kepada langkah kecil dengan soalan checkpoint sebelum murid bergerak ke aktiviti seterusnya.']
];

const groups = {
  bakawali: {
    name: 'Bakawali',
    level: 'Baik',
    number: '01',
    color: 'coral',
    icon: 'B',
    descriptor: 'Cabaran kendiri & penaakulan',
    outcome: 'Menghasilkan rumusan tiga isi penting dan satu ramalan berjustifikasi.',
    steps: ['Baca dua kali dan tandakan isi penting.', 'Bandingkan objek angkasa dalam AR.', 'Bina ramalan teknologi angkasa 2050.', 'Kongsi hasil di papan IdeaFlip.'],
    tools: [
      { label: 'FlipHTML5 · Buku Cerita Digital', href: 'https://online.fliphtml5.com/lfgfji/BUKU-IMPIAN-ADAM-KE-ANGKASA-kxTM/' },
      { label: 'Assemblr Edu · AR 3D', href: 'https://assemblredu-h4kw6ffu.manus.space/' },
      { label: 'IdeaFlip · Ruang Ramalan', href: 'https://ideaflip.com/edit/ggbbyrhxtqf5/yOYCnyw6WqNX' },
      { label: 'Gemini AI · Poster', href: 'https://gemini.google.com/app' }
    ],
    success: ['Tiga isi tentang angkasa', 'Satu ramalan berjustifikasi', 'Poster Misi Angkasa 2050']
  },
  sakura: {
    name: 'Sakura',
    level: 'Sederhana',
    number: '02',
    color: 'mint',
    icon: 'S',
    descriptor: 'Bimbingan berstruktur',
    outcome: 'Mengenal pasti dua isi penting dan membina satu ramalan berpandukan kad soalan.',
    steps: ['Baca dengan panduan kad soalan.', 'Teroka satu objek AR dan catat cirinya.', 'Lengkapkan peta pemikiran Canva.', 'Semak rumusan bersama rakan.'],
    tools: [
      { label: 'FlipHTML5 · Buku Cerita Digital', href: 'https://online.fliphtml5.com/lfgfji/BUKU-IMPIAN-ADAM-KE-ANGKASA-kxTM/' },
      { label: 'Assemblr Edu · AR 3D', href: 'https://assemblredu-h4kw6ffu.manus.space/' },
      { label: 'Canva · Kad & Peta Pemikiran', href: 'https://canva.link/l04uq647iokffd1' },
      { label: 'IdeaFlip · Ruang Rumusan', href: 'https://ideaflip.com/edit/kgk8j7ky8c23/akQjjfeJToNX' }
    ],
    success: ['Dua isi tentang angkasa', 'Satu ramalan berpandukan kad', 'Peta pemikiran lengkap']
  },
  akasia: {
    name: 'Akasia',
    level: 'Asas',
    number: '03',
    color: 'violet',
    icon: 'A',
    descriptor: 'Sokongan audio & langkah demi langkah',
    outcome: 'Mengisi tiga tempat kosong dan menyatakan satu ramalan berpandukan gambar.',
    steps: ['Dengar bacaan model guru.', 'Kenal pasti kata kunci berwarna.', 'Lengkapkan rumusan berpandu.', 'Cuba permainan pemulihan Wordwall.'],
    tools: [
      { label: 'Audio guru · Pengenalan', href: '/audio/pengenalan-angkasa.wav' },
      { label: 'Google Docs · Rumusan Berpandu', href: 'https://docs.google.com/document/d/1xjhR2s5MSzIW5gGLx-nhywcsDI3E7t52rVVaHPfgDsg/edit?usp=sharing' },
      { label: 'Wordwall · Pemulihan', href: 'https://wordwall.net/resource/120958333?wwmethod=link' },
      { label: 'Assemblr Edu · Gambar AR', href: 'https://assemblredu-h4kw6ffu.manus.space/' }
    ],
    success: ['Tiga kata kunci tepat', 'Tiga tempat kosong lengkap', 'Satu ramalan berpandukan gambar']
  }
};

const explorerItems = {
  bulan: { label: 'Bulan', tag: 'SATELIT SEMULA JADI', detail: 'Bulan memantulkan cahaya Matahari. Fasa Bulan berubah kerana kedudukannya berbanding Bumi dan Matahari.', fact: 'Boleh menjadi penanda masa dan bahan kajian permukaan angkasa.' },
  planet: { label: 'Planet', tag: 'DUNIA YANG MENGELILINGI BINTANG', detail: 'Planet mengorbit bintang. Bumi ialah planet yang menyokong kehidupan kerana mempunyai air, udara dan suhu yang sesuai.', fact: 'Teknologi teleskop membantu manusia memerhati planet yang jauh.' },
  roket: { label: 'Roket', tag: 'KENDERAAN PENEROKAAN', detail: 'Roket menggunakan tujahan untuk melawan graviti dan membawa manusia atau peralatan ke angkasa.', fact: 'Roket masa hadapan mungkin menggunakan tenaga lebih bersih dan boleh diguna semula.' },
  angkasawan: { label: 'Angkasawan', tag: 'PENEROKA & PENYELIDIK', detail: 'Angkasawan menjalankan eksperimen, menyelenggara peralatan dan memerhati Bumi dari orbit.', fact: 'Kemahiran membaca arahan dan menaakul sangat penting untuk keselamatan misi.' }
};

const quiz = [
  { q: 'Apakah isi penting yang paling tepat berdasarkan bahan “Impian Adam ke Angkasa”?', options: ['Adam mahu meneroka dan memahami dunia angkasa.', 'Adam mahu membeli roket mainan sahaja.', 'Adam tidak berminat dengan sains.', 'Adam mahu tinggal di dalam teleskop.'], answer: 0, why: 'Bahan menekankan minat Adam untuk meneroka, memahami dan membayangkan masa depan angkasa.' },
  { q: 'Apakah fungsi utama teleskop?', options: ['Menghasilkan bunyi di angkasa.', 'Membolehkan objek jauh dilihat dengan lebih jelas.', 'Membawa angkasawan ke Bulan.', 'Mengukur suhu badan.'], answer: 1, why: 'Teleskop mengumpul cahaya dan membantu manusia memerhati objek yang jauh.' },
  { q: 'Ramalan yang manakah paling berjustifikasi?', options: ['Semua manusia akan tinggal di Matahari.', 'Roket masa hadapan mungkin lebih jimat tenaga kerana teknologi berkembang.', 'Bulan akan menjadi lebih besar esok.', 'Teleskop tidak lagi diperlukan.'], answer: 1, why: 'Ramalan yang baik disokong oleh sebab: teknologi berkembang dan boleh menjadikan roket lebih cekap.' },
  { q: 'Dalam rumusan, kita perlu memilih…', options: ['Semua ayat tanpa menyusun idea.', 'Isi penting dan menulisnya dengan tersusun.', 'Hanya gambar yang paling cantik.', 'Soalan yang paling panjang.'], answer: 1, why: 'Rumusan yang baik memilih isi penting dan menggabungkannya secara ringkas serta tersusun.' },
  { q: 'Apakah sikap yang sesuai semasa aktiviti digital?', options: ['Menyalin jawapan tanpa membaca.', 'Berkongsi kata laluan dengan semua orang.', 'Menyemak sumber dan menghormati idea rakan.', 'Menutup aktiviti apabila soalan sukar.'], answer: 2, why: 'Pembelajaran digital memerlukan tanggungjawab, semakan sumber dan kerjasama yang beretika.' }
];

const checklistItems = [
  'Membaca bahan multimedia dengan sebutan dan intonasi yang sesuai.',
  'Mengenal pasti isi penting daripada teks dan visual.',
  'Menghubungkan maklumat untuk membuat rumusan.',
  'Membina ramalan yang disokong alasan atau bukti.',
  'Menggunakan media digital secara beretika dan selamat.'
];

function icon(name) {
  const icons = {
    arrow: '<span class="icon-arrow">↗</span>',
    play: '<span class="icon-play">▶</span>',
    check: '<span class="icon-check">✓</span>',
    orbit: '<span class="icon-orbit">◎</span>',
    star: '<span class="icon-star">✦</span>'
  };
  return icons[name] || '';
}

function render() {
  app.innerHTML = `
    <div class="app-shell">
      ${renderTopbar()}
      <main>${renderPage()}</main>
      ${renderFooter()}
      ${renderChatbot()}
      ${state.toast ? `<div class="toast">${state.toast}</div>` : ''}
    </div>
  `;
  bindEvents();
}

function renderTopbar() {
  return `
    <header class="topbar">
      <a class="brand" href="#home" data-nav="home" aria-label="Ke halaman utama">
        <span class="brand-mark"><span></span><i></i></span>
        <span><strong>TEROKAI</strong><small>ANGKASA KITA</small></span>
      </a>
      <div class="top-meta"><span class="status-dot"></span> BAHASA MELAYU · TAHUN 6 · SAINS, TEKNOLOGI DAN INOVASI | TEROKAI ANGKASA KITA</div>
      <button class="menu-button" data-action="toggle-menu" aria-expanded="${state.menuOpen}">MENU <span>☰</span></button>
    </header>
    <nav class="main-nav ${state.menuOpen ? 'open' : ''}" id="main-nav" aria-label="Navigasi utama">
      ${navItems.map(item => `<button class="nav-item ${state.section === item.id ? 'active' : ''}" data-nav="${item.id}"><small>${item.eyebrow}</small><span>${item.label}</span></button>`).join('')}
    </nav>
  `;
}

function renderPage() {
  if (state.section === 'metadata') return renderMetadata();
  if (state.section === 'assure') return renderAssure();
  if (state.section === 'segment1') return renderSegment1();
  if (state.section === 'segment2') return renderSegment2();
  if (['segment3', 'assessment', 'game', 'closing'].includes(state.section)) return renderSegment3();
  if (state.section === 'guidance') return renderGuidance();
  return renderHome();
}

function renderHome() {
  return `
    <section class="hero-section page-pad">
      <div class="hero-copy">
        <div class="eyebrow-line"><span>01</span><span class="line"></span><span>RUANG PEMBELAJARAN DIGITAL</span></div>
        <h1>Terokai<br><em>Angkasa Kita</em></h1>
        <p class="hero-lede">Sebuah misi membaca, memahami dan menaakul bahan multimedia — untuk melihat lebih jauh daripada bintang.</p>
        <div class="hero-actions"><button class="primary-btn" data-nav="segment1">Mulakan misi ${icon('arrow')}</button><button class="text-btn" data-nav="assure">Lihat model ASSURE ${icon('arrow')}</button></div>
        <div class="mission-note"><span class="note-number">A</span><span><b>MISI HARI INI</b><br>Lengkapkan rumusan isi penting dan bina satu ramalan tentang angkasa.</span></div>
      </div>
      <div class="hero-art" aria-label="Ilustrasi orbit angkasa">
        <div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="orbit orbit-three"></div>
        <div class="planet planet-large"><span></span></div><div class="planet planet-small"></div><div class="asteroid asteroid-one"></div><div class="asteroid asteroid-two"></div>
        <span class="star-particle p1">✦</span><span class="star-particle p2">·</span><span class="star-particle p3">✦</span><span class="star-particle p4">+</span>
        <div class="hero-art-label"><span class="label-line"></span><small>OBJEK PILIHAN</small><strong>ROKET · 2050</strong></div>
      </div>
    </section>

    <section class="marquee"><div class="marquee-inner"><span>BAHASA MELAYU TAHUN 6</span><b>✦</b><span>TEMA: SAINS, TEKNOLOGI & INOVASI</span><b>✦</b><span>SK 2.2 · SP 2.2.1</span><b>✦</b><span>BAHASA MELAYU TAHUN 6</span></div></section>

    <section class="page-pad intro-grid">
      <div class="section-kicker">/ 00 — TAKLIMAT MISI</div>
      <div class="intro-main"><h2>Perjalanan ini<br>bermula dengan <em>satu soalan.</em></h2><p>Bagaimana kita membaca dunia yang belum pernah kita jejaki? Ikuti empat checkpoint pembelajaran untuk meneroka cerita, objek angkasa, idea masa hadapan dan suara anda sendiri.</p></div>
      <div class="intro-side"><div class="metric"><strong>25</strong><span>murid<br>6 Dahlia</span></div><div class="metric"><strong>03</strong><span>laluan<br>pembelajaran</span></div><div class="metric"><strong>05</strong><span>checkpoint<br>misi</span></div></div>
    </section>

    <section class="page-pad pathway-section">
      <div class="section-heading"><div><div class="section-kicker">/ PETA PERJALANAN</div><h2>Empat checkpoint.<br><em>Satu misi bersama.</em></h2></div><span class="section-index">01 / 04</span></div>
      <div class="pathway-grid">
        ${pathwayCard('01','Cetus idea','Segmen 1','Bina hubungan dengan tajuk melalui kostum, lagu dan soalan awal.','segment1','coral')}
        ${pathwayCard('02','Teroka & analisis','Segmen 2','Baca “Impian Adam ke Angkasa”, amati AR 3D dan fahami isi penting.','segment2','mint')}
        ${pathwayCard('03','Aplikasi','Segmen 3','Hasilkan poster, cuba pemulihan dan uji kefahaman anda.','segment3','violet')}
        <div class="pathway-card last-card"><div class="card-number">04</div><div><small>REFLEKSI</small><h3>Nilai semula</h3><p>Kongsi apa yang anda pelajari dan bantu kami menambah baik PdP.</p><button class="circle-btn" data-action="open-exit">${icon('arrow')}</button></div></div>
      </div>
    </section>

    <section class="page-pad objective-band"><div><div class="section-kicker">/ OBJEKTIF PEMBELAJARAN</div><h2>Pada akhir misi, anda boleh membaca dan menganalisis bahan multimedia untuk melengkapkan rumusan isi penting dengan tersusun.</h2></div><div class="target-mark">◎<small>OP</small></div></section>

    <section class="page-pad group-preview"><div class="section-heading"><div><div class="section-kicker">/ LALUAN BERBEZA</div><h2>Semua murid boleh<br><em>sampai ke bintang.</em></h2></div><button class="text-btn" data-nav="segment2">Teroka semua laluan ${icon('arrow')}</button></div><div class="group-preview-grid">${Object.values(groups).map(group => `<button class="group-chip ${group.color}" data-nav="segment2" data-group="${group.name.toLowerCase()}"><span class="group-icon">${group.icon}</span><span><b>${group.name}</b><small>${group.level} · ${group.descriptor}</small></span>${icon('arrow')}</button>`).join('')}</div></section>
  `;
}

function pathwayCard(number, eyebrow, title, copy, target, color) {
  return `<button class="pathway-card ${color}" data-nav="${target}"><div class="card-number">${number}</div><div><small>${eyebrow}</small><h3>${title}</h3><p>${copy}</p><span class="circle-btn">${icon('arrow')}</span></div></button>`;
}


function renderMetadata() {
  const materials = [
    ['YouTube', 'Lagu Cita-Citaku', 'Video / audio set induksi', materialLinks.youtube, 'coral'],
    ['FlipHTML5', 'Impian Adam ke Angkasa', 'Buku cerita digital', materialLinks.fliphtml5, 'mint'],
    ['Assemblr Edu', 'Objek AR 3D angkasa', 'Penerokaan planet, Bulan dan roket', materialLinks.assemblr, 'violet'],
    ['IdeaFlip', 'Ruang ramalan Bakawali', 'Catatan dan idea teknologi 2050', materialLinks.ideaflip, 'amber'],
    ['Canva', 'Kad soalan & peta pemikiran', 'Laluan Sakura', materialLinks.canvaMap, 'blue'],
    ['Google Docs', 'Lembaran rumusan berpandu', 'Laluan Akasia', materialLinks.docs, 'pink'],
    ['Gemini AI', 'Poster Misi Angkasa 2050', 'Aktiviti pengayaan', materialLinks.gemini, 'lime'],
    ['Wordwall', 'Padanan objek dan fungsi', 'Aktiviti pemulihan', materialLinks.wordwall, 'indigo'],
    ['Kahoot', 'Kuiz pengukuhan', 'Maklum balas serta-merta', materialLinks.kahoot, 'coral'],
    ['Google Form', 'Exit Ticket Digital', 'Refleksi kendiri & media', materialLinks.forms, 'mint']
  ];
  return `<section class="page-pad inner-page metadata-page"><div class="page-intro split-intro"><div><div class="eyebrow-line"><span>01</span><span class="line"></span><span>PENGENALAN DSKP & RPH</span></div><h1>Kenali<br><em>misi anda.</em></h1></div><p>Rujukan ringkas kepada DSKP, RPH dan bahan pembelajaran yang menyokong “Terokai Angkasa Kita”. Klik mana-mana kad untuk membuka bahan asal.</p></div><div class="metadata-hero"><div><span class="tag">RPH DIGITAL · BAHASA MELAYU TAHUN 6 DAHLIA</span><h2>Terokai Angkasa Kita</h2><p>Tema: Sains, Teknologi dan Inovasi · Tarikh: 16 Oktober 2026 · Masa: 10.30 pagi – 11.30 pagi</p></div><div class="meta-stamp"><b>25</b><small>MURID</small></div></div><div class="metadata-grid"><article><span class="tag">DSKP</span><h3>SK 2.2</h3><p>Membaca, memahami dan menaakul bahan multimedia.</p></article><article><span class="tag">DSKP</span><h3>SP 2.2.1</h3><p>Membaca, memahami dan menaakul bahan multimedia untuk membuat rumusan dan ramalan.</p></article><article><span class="tag">OBJEKTIF</span><h3>OP</h3><p>Murid dapat membaca dan menganalisis bahan multimedia melalui buku cerita digital dan AR 3D untuk melengkapkan rumusan isi penting dengan tersusun.</p></article></div><div class="criteria-table"><div class="criteria-title"><span class="section-kicker">/ KRITERIA KEJAYAAN</span><h2>Tiga laluan, satu hasil pembelajaran.</h2></div>${Object.values(groups).map(group => `<div class="criteria-row"><span class="group-icon">${group.icon}</span><b>${group.name}<small>${group.level}</small></b><p>${group.outcome}</p><div>${group.success.map(item => `<span>${icon('check')} ${item}</span>`).join('')}</div></div>`).join('')}</div><div class="concept-section"><div class="section-heading"><div><div class="section-kicker">/ PENERANGAN KONSEP</div><h2>Mengapa media ini<br><em>disusun begini?</em></h2></div><span class="section-index">TEORI MAYER</span></div><div class="concept-grid">${conceptPrinciples.map((item, index) => `<article><span>0${index + 1}</span><h3>${item[0]}</h3><p>${item[1]}</p></article>`).join('')}</div></div><div class="resource-section"><div class="section-heading"><div><div class="section-kicker">/ BANK BAHAN RPH</div><h2>Preview & buka<br><em>bahan sebenar.</em></h2></div><p class="resource-note">Kad ini ialah pintasan terus ke platform yang dirujuk dalam RPH. Sesetengah bahan memerlukan akaun sekolah atau akses guru.</p></div><div class="resource-grid">${materials.map(item => `<a class="resource-card ${item[4]}" href="${item[3]}" target="_blank" rel="noreferrer"><div class="resource-thumb"><span>${item[0].slice(0,2).toUpperCase()}</span><i>${icon('arrow')}</i></div><div><small>${item[0]}</small><h3>${item[1]}</h3><p>${item[2]}</p></div></a>`).join('')}</div></div></section>`;
}

function renderAssure() {
  const steps = [
    ['A','Analyze Learners','Analisis Murid','25 murid · tiga profil kesediaan','Kenal pasti tahap penguasaan, keperluan bimbingan dan kompetensi digital.','coral'],
    ['S','State Objectives','Nyatakan Objektif','SK 2.2 · SP 2.2.1','Murid membaca, memahami dan menaakul bahan multimedia untuk membuat rumusan dan ramalan.','mint'],
    ['S','Select Methods','Pilih Strategi & Media','Pembelajaran terbeza','Gabungkan buku cerita digital, AR 3D, peta pemikiran dan alat pentaksiran.','violet'],
    ['U','Utilize Materials','Gunakan Teknologi','Baca · teroka · bina','Gunakan media dengan arahan ringkas, contoh visual dan sokongan berperingkat.','amber'],
    ['R','Require Participation','Libatkan Murid','Murid sebagai peneroka','Murid memilih laluan, menjawab soalan, berbincang dan mencipta hasil.','blue'],
    ['E','Evaluate & Revise','Nilai & Tambah Baik','Bukti pembelajaran','Senarai semak, kuiz, rumusan, poster dan exit ticket memandu tindakan seterusnya.','pink']
  ];
  return `<section class="page-pad inner-page"><div class="page-intro"><div class="eyebrow-line"><span>02</span><span class="line"></span><span>RANGKA PdP</span></div><h1>Model <em>ASSURE</em></h1><p>Enam langkah untuk merancang pengalaman pembelajaran yang jelas, terbeza dan aktif.</p></div><div class="assure-map">${steps.map((step, i) => `<article class="assure-step ${step[5]}"><div class="assure-letter">${step[0]}</div><div class="assure-step-top"><span>0${i + 1}</span><small>${step[1]}</small></div><h3>${step[2]}</h3><b>${step[3]}</b><p>${step[4]}</p></article>`).join('')}</div><div class="assure-quote"><span>“</span><p>Reka bentuk yang baik tidak meninggalkan sesiapa di belakang — ia membuka lebih banyak pintu untuk setiap murid masuk.</p><small>PRINSIP PEMBELAJARAN TERBEZA</small></div></section>`;
}

function renderSegment1() {
  return `<section class="page-pad inner-page"><div class="page-intro split-intro"><div><div class="eyebrow-line"><span>03</span><span class="line"></span><span>CETUS IDEA</span></div><h1>Segmen 1<br><em>Berangkat!</em></h1></div><p>Mulakan dengan rasa ingin tahu. Dengar, lihat, nyanyi dan hubungkan pengalaman anda dengan angkasa.</p></div><div class="concept-callout"><div><span class="tag">OPD PENERANGAN KONSEP</span><h2>Audio memulakan imaginasi.<br>Visual membantu memahami.</h2><p>Dengar narasi Bahasa Melayu, baca kata kunci pada skrin dan gunakan soalan cetusan untuk mengaktifkan pengetahuan sedia ada.</p></div><div class="concept-stack"><span>TEKS</span><span>GRAFIK</span><span>AUDIO</span><span>VIDEO</span><span>ANIMASI</span><span>AI</span></div></div><div class="launch-card"><div class="launch-visual"><div class="launch-orbit"></div><div class="launch-planet"></div><div class="launch-rocket">▲</div><span class="launch-star one">✦</span><span class="launch-star two">✦</span><div class="launch-caption"><small>VIDEO / AUDIO PENGENALAN</small><strong>CITA-CITAKU</strong><span>1:42 min · Guru Michelle</span></div></div><div class="launch-info"><div class="tag">RINGKASAN AUDIO VISUAL</div><h2>Adakah anda bersedia menuju lebih jauh?</h2><p>Bayangkan anda memakai kostum angkasawan. Apa yang anda lihat apabila memandang ke langit? Tonton pengenalan, ikut lirik dan bersedia untuk membaca cerita Adam.</p><button class="primary-btn" data-action="play-intro">${icon('play')} Mainkan pengenalan</button><audio class="intro-audio" controls preload="metadata" src="/audio/pengenalan-angkasa.wav" aria-label="Audio pengenalan Bahasa Melayu"></audio><div class="audio-note"><span class="audio-bars"><i></i><i></i><i></i><i></i><i></i></span><span>Audio pengenalan · Bahasa Melayu Malaysia</span></div></div></div><div class="prompt-row"><div class="prompt-label"><span>01</span><b>SOALAN CETUSAN</b><small>Tulis idea anda. Guru boleh menyemak respons murid semasa perbincangan.</small></div><div class="prompt-cards"><form class="prompt-card idea-form" data-prompt="0"><span>01</span><p>Apakah yang anda tahu tentang angkasa?</p><textarea placeholder="Tulis idea anda di sini…"></textarea><button class="mini-save" type="submit">Simpan idea ${icon('arrow')}</button></form><form class="prompt-card idea-form" data-prompt="1"><span>02</span><p>Apakah objek yang anda jangka akan ditemui?</p><textarea placeholder="Contoh: roket, planet…"></textarea><button class="mini-save" type="submit">Simpan idea ${icon('arrow')}</button></form><form class="prompt-card idea-form" data-prompt="2"><span>03</span><p>Bagaimanakah manusia meneroka angkasa?</p><textarea placeholder="Saya meramalkan… kerana…"></textarea><button class="mini-save" type="submit">Simpan idea ${icon('arrow')}</button></form></div></div><div class="next-banner"><span>${icon('arrow')}</span><div><small>SETERUSNYA</small><b>Buka buku cerita digital dan temui misi Adam.</b></div><button class="text-btn" data-nav="segment2">Pergi ke Segmen 2 ${icon('arrow')}</button></div></section>`;
}

function renderSegment2() {
  const group = groups[state.activeGroup];
  const item = explorerItems[state.explorer];
  return `<section class="page-pad inner-page"><div class="page-intro split-intro"><div><div class="eyebrow-line"><span>04</span><span class="line"></span><span>TEROKA & ANALISIS</span></div><h1>Segmen 2<br><em>Temui jawapan.</em></h1></div><p>Ikuti cerita, dekati objek angkasa dan pilih laluan aktiviti yang paling sesuai dengan cara anda belajar.</p></div><div class="story-lab"><a class="story-book material-link" href="${materialLinks.fliphtml5}" target="_blank" rel="noreferrer"><div class="book-top"><span>FLIPHTML5 / BUKU CERITA DIGITAL</span><span>01 / 08</span></div><div class="book-illustration"><div class="book-moon"></div><div class="book-earth"></div><div class="book-window"><span>IMPIAN ADAM<br><b>KE ANGKASA</b></span></div><span class="book-star a">✦</span><span class="book-star b">✦</span></div><div class="book-copy"><div><small>HALAMAN PEMBUKAAN</small><h2>Impian Adam ke Angkasa</h2></div><span class="circle-btn">${icon('arrow')}</span></div><div class="book-progress"><span style="width:34%"></span></div></div></a><div class="object-lab"><div class="lab-head"><div><span class="tag">ASSEMBLR EDU / AR 3D</span><h2>Pilih satu objek untuk diteroka.</h2></div><span class="lab-status"><i></i> SIMULASI AKTIF</span><a class="resource-link" href="${materialLinks.assemblr}" target="_blank" rel="noreferrer">Buka Assemblr Edu ${icon('arrow')}</a></div><div class="object-view"><div class="object-ring"></div><div class="object-visual ${state.explorer}"></div><span class="object-coord">03° 14′ N<br>101° 41′ E</span><div class="object-detail"><small>${item.tag}</small><h3>${item.label}</h3><p>${item.detail}</p><b>+ ${item.fact}</b></div></div><div class="object-tabs">${Object.entries(explorerItems).map(([key, value]) => `<button class="object-tab ${state.explorer === key ? 'active' : ''}" data-object="${key}"><span>${objectGlyph(key)}</span>${value.label}</button>`).join('')}</div></div></div>${renderInteractiveVideo()}<div class="group-workspace"><div class="workspace-head"><div><div class="section-kicker">/ RUANG KERJA TERBEZA</div><h2>Pilih laluan pembelajaran anda.</h2></div><div class="group-switcher">${Object.entries(groups).map(([key, value]) => `<button class="group-tab ${state.activeGroup === key ? 'active ' + value.color : ''}" data-group="${key}"><span>${value.icon}</span>${value.name}</button>`).join('')}</div></div><div class="workspace-body ${group.color}"><div class="group-title"><div class="group-big-icon">${group.icon}</div><div><span class="tag">KUMPULAN ${group.number}</span><h3>${group.name} <em>· ${group.level}</em></h3><p>${group.descriptor}</p></div></div><div class="workspace-grid"><div><small class="label-caps">TUGAS ANDA</small><ol>${group.steps.map(step => `<li>${step}</li>`).join('')}</ol></div><div><small class="label-caps">KRITERIA KEJAYAAN</small><ul class="success-list">${group.success.map(item => `<li>${icon('check')} ${item}</li>`).join('')}</ul><div class="workspace-outcome"><b>HASIL DIJANGKA</b><span>${group.outcome}</span></div><form class="group-response-form" data-group-response="${state.activeGroup}"><label for="response-${state.activeGroup}">RUANG IDEA KUMPULAN</label><textarea id="response-${state.activeGroup}" placeholder="Tulis rumusan, ramalan atau alasan kumpulan anda…">${state.groupResponses[state.activeGroup] || ''}</textarea><button class="mini-save" type="submit">Simpan respons kumpulan ${icon('arrow')}</button></form></div></div><div class="tool-row"><small>MEDIA PILIHAN</small>${group.tools.map(tool => `<a class="tool-link" href="${tool.href}" target="_blank" rel="noreferrer">${tool.label} ${icon('arrow')}</a>`).join('')}</div></div></div><div class="prediction-card"><div><span class="tag">PENAakulan / RAMALAN</span><h2>Lengkapkan ayat ini:</h2><p>“Pada tahun 2050, manusia mungkin akan __________ kerana __________.”</p></div><button class="primary-btn" data-action="save-prediction">Simpan ramalan ${icon('arrow')}</button></div><div class="assessment-mini"><span class="assessment-icon">✓</span><div><b>PENTAKSIRAN PROSES</b><p>Guru menanda senarai semak semasa anda membaca, mengenal pasti isi penting dan membuat ramalan.</p></div><button class="text-btn" data-action="open-checklist">Buka senarai semak ${icon('arrow')}</button></div><div class="next-banner"><span>${icon('arrow')}</span><div><small>SETERUSNYA</small><b>Semak bukti pembelajaran dalam Penilaian.</b></div><button class="text-btn" data-nav="assessment">Pergi ke Penilaian ${icon('arrow')}</button></div></section>`;
}


function renderInteractiveVideo() {
  const checkpoints = [
    { time: '00:18', question: 'Apakah idea utama yang diperkenalkan dalam video?', options: ['Adam ingin meneroka angkasa.', 'Adam tidak suka membaca.', 'Adam mahu bermain bola.'], answer: 0, feedback: 'Betul. Video memperkenalkan rasa ingin tahu Adam terhadap angkasa.' },
    { time: '00:47', question: 'Apakah media yang membantu kita melihat objek yang jauh?', options: ['Teleskop', 'Papan putih', 'Kamus'], answer: 0, feedback: 'Tepat. Teleskop membantu kita memerhati objek jauh dengan lebih jelas.' },
    { time: '01:16', question: 'Pilih ramalan yang disokong alasan.', options: ['Roket mungkin lebih cekap kerana teknologi berkembang.', 'Bulan akan jatuh ke Bumi esok.', 'Semua planet mempunyai udara yang sama.'], answer: 0, feedback: 'Bagus. Ramalan ini mempunyai sebab yang boleh diterangkan.' }
  ];
  const checkpoint = checkpoints[state.videoStep];
  return `<div class="interactive-video"><div class="video-head"><div><span class="tag">OPD VIDEO INTERAKTIF · H5P / EDPUZZLE</span><h2>Tonton, berhenti, jawab.</h2></div></div><div class="video-stage"><div class="video-screen"><video class="generated-video" controls preload="metadata" src="/video/impian-adam-angkasa.mp4" aria-label="Video animasi Impian Adam ke Angkasa"></video><div class="video-overlay"><div class="video-play">${icon('play')}</div><span class="video-caption">ANIMASI · IMPIAN ADAM KE ANGKASA</span><span class="video-time">${checkpoint.time} / 00:05</span></div></div><div class="video-track"><span style="width:${((state.videoStep + (state.videoAnswered ? 1 : 0)) / checkpoints.length) * 100}%"></span></div></div><div class="video-question"><div class="checkpoint-label"><span>${String(state.videoStep + 1).padStart(2,'0')}</span><small>CHECKPOINT SOALAN</small></div><div><h3>${checkpoint.question}</h3><div class="video-options">${checkpoint.options.map((option, index) => `<button class="video-option ${state.videoAnswered ? (index === checkpoint.answer ? 'correct' : 'muted') : ''}" data-video-answer="${index}" ${state.videoAnswered ? 'disabled' : ''}><span>${String.fromCharCode(65 + index)}</span>${option}</button>`).join('')}</div>${state.videoAnswered ? `<div class="video-feedback">${icon('check')} ${checkpoint.feedback} <button class="text-btn" data-action="next-video">${state.videoStep === checkpoints.length - 1 ? 'Ulang checkpoint' : 'Checkpoint seterusnya'} ${icon('arrow')}</button></div>` : '<p class="quiz-hint">Video akan berhenti di sini — pilih jawapan sebelum meneruskan.</p>'}</div></div></div>`;
}

function objectGlyph(key) {
  return { bulan: '◐', planet: '◉', roket: '△', angkasawan: '◇' }[key];
}

function renderSegment3() {
  if (state.section === 'game') return renderGamePanel();
  if (state.section === 'closing') return renderClosingPanel();
  return renderAssessmentPanel();
}

function renderAssessmentPanel() {
  return `<section class="page-pad inner-page"><div class="page-intro split-intro"><div><div class="eyebrow-line"><span>05</span><span class="line"></span><span>PENILAIAN</span></div><h1>Bukti<br><em>pembelajaran.</em></h1></div><p>Guru melihat bukti melalui senarai semak, respons kumpulan, rumusan, poster dan refleksi murid.</p></div><div class="assessment-overview"><div><span class="tag">INSTRUMEN UTAMA</span><h2>Senarai semak proses membaca & menaakul</h2><p>Gunakan semasa murid membaca bahan multimedia, mengenal pasti isi penting dan membina ramalan berjustifikasi.</p><button class="primary-btn" data-action="open-checklist">Buka senarai semak ${icon('arrow')}</button></div><div class="assessment-orbit"><span>✓</span><small>5 indikator</small></div></div><div class="evidence-grid"><article><span>01</span><h3>Respons lisan & bertulis</h3><p>Idea murid direkodkan dalam Soalan Cetusan dan ruang respons kumpulan.</p></article><article><span>02</span><h3>Rumusan & ramalan</h3><p>Semak isi penting, susunan idea dan sebab yang menyokong ramalan.</p></article><article><span>03</span><h3>Produk digital</h3><p>Nilai poster Misi Angkasa 2050, peta pemikiran dan latihan pemulihan.</p></article></div><div class="next-banner"><span>${icon('arrow')}</span><div><small>SETERUSNYA</small><b>Uji kefahaman dalam Permainan.</b></div><button class="text-btn" data-nav="game">Pergi ke Permainan ${icon('arrow')}</button></div></section>`;
}

function renderGamePanel() {
  return `<section class="page-pad inner-page"><div class="page-intro split-intro"><div><div class="eyebrow-line"><span>06</span><span class="line"></span><span>PERMAINAN</span></div><h1>Main,<br><em>uji & kukuh.</em></h1></div><p>Zon pengayaan, zon pemulihan dan e-pentaksiran gamifikasi membantu murid memilih cabaran yang sesuai.</p></div><div class="activity-columns"><article class="activity-card enrichment"><div class="activity-number">A</div><div class="activity-icon">✦</div><span class="tag">ZON PENGAYAAN</span><h2>Misi Angkasa 2050</h2><p>Cipta poster digital yang menghubungkan sifat Adam dengan ramalan teknologi angkasa yang anda bina.</p><div class="activity-list"><span>01 · Pilih ciri watak Adam</span><span>02 · Tulis ramalan dan sebab</span><span>03 · Hasilkan poster bersama Gemini AI</span></div><a class="outline-btn" href="${materialLinks.gemini}" target="_blank" rel="noreferrer">Buka Gemini AI ${icon('arrow')}</a></article><article class="activity-card remediation"><div class="activity-number">R</div><div class="activity-icon">▦</div><span class="tag">ZON PEMULIHAN</span><h2>Padankan & faham</h2><p>Padankan objek angkasa dengan fungsi yang betul, kemudian lengkapkan rumusan berpandu.</p><div class="activity-list"><span>01 · Main padanan objek AR</span><span>02 · Baca semula cerita dengan audio</span><span>03 · Lengkapkan kata kunci</span></div><a class="outline-btn" href="${materialLinks.wordwall}" target="_blank" rel="noreferrer">Cuba Wordwall ${icon('arrow')}</a></article></div><div class="quiz-zone"><div class="quiz-intro"><span class="tag">E-PENTAKSIRAN GAMIFIKASI</span><h2>Kuiz orbit</h2><p>Jawab lima soalan. Dapatkan maklum balas serta-merta untuk setiap orbit.</p><div class="score-display"><strong>${String(state.score).padStart(2,'0')}</strong><span>mata<br>semasa</span></div></div><div class="quiz-card">${renderQuiz()}</div></div><div class="next-banner"><span>${icon('arrow')}</span><div><small>SETERUSNYA</small><b>Renung pengalaman anda dalam Penutup.</b></div><button class="text-btn" data-nav="closing">Pergi ke Penutup ${icon('arrow')}</button></div></section>`;
}

function renderClosingPanel() {
  return `<section class="page-pad inner-page"><div class="page-intro split-intro"><div><div class="eyebrow-line"><span>07</span><span class="line"></span><span>PENUTUP</span></div><h1>Jangan lupa<br><em>tinggalkan jejak.</em></h1></div><p>Semak semula jawapan, jawab exit ticket dan berikan maklum balas tentang media digital yang membantu pembelajaran.</p></div><div class="closing-grid"><div class="exit-ticket"><div class="exit-copy"><span class="tag">EXIT TICKET DIGITAL</span><h2>Bagaimana misi anda hari ini?</h2><p>Nilai pemahaman anda dan beritahu kami media yang paling membantu.</p></div><form id="exit-form"><label>Hari ini saya boleh…<select name="confidence"><option value="5">Membuat rumusan dan ramalan dengan yakin</option><option value="4">Menerangkan isi penting dengan sedikit bantuan</option><option value="3">Mengenal pasti kata kunci dengan bimbingan</option></select></label><label>Media yang paling membantu…<select name="media"><option>Buku Cerita Digital</option><option>AR 3D Assemblr Edu</option><option>Kuiz Orbit</option><option>Peta pemikiran / Google Docs</option></select></label><label class="check-label"><input type="checkbox" name="helpful" checked> Media digital membantu saya belajar hari ini.</label><button class="primary-btn" type="submit">Hantar refleksi ${icon('arrow')}</button>${state.exitSaved ? '<div class="saved-note">✓ Terima kasih. Refleksi anda telah direkodkan.</div>' : ''}</form></div><div class="closing-kahoot"><span class="tag">PENGUKUHAN RPH</span><h2>Semak jawapan dalam Kahoot.</h2><p>Gunakan kuiz asal RPH untuk menyemak kefahaman secara berkumpulan sebelum murid menghantar exit ticket.</p><a class="primary-btn" href="${materialLinks.kahoot}" target="_blank" rel="noreferrer">Buka Kahoot RPH ${icon('arrow')}</a></div></div><div class="cc-footer"><span class="cc-badge">✓</span><p>Guru boleh menggunakan respons Kahoot dan Google Form untuk memberi maklum balas, membetulkan salah faham dan merumuskan nilai kerajinan, kegigihan serta kerjasama.</p></div><div class="next-banner"><span>${icon('arrow')}</span><div><small>SETERUSNYA</small><b>Rujuk Panduan peranan guru dan murid.</b></div><button class="text-btn" data-nav="guidance">Pergi ke Panduan ${icon('arrow')}</button></div></section>`;
}

function renderQuiz() {
  if (state.quizIndex >= quiz.length) return `<div class="quiz-complete"><div class="complete-mark">${state.score >= 4 ? '★' : '✓'}</div><span class="tag">MISI SELESAI</span><h3>${state.score >= 4 ? 'Orbit anda mantap!' : 'Misi berjaya diselesaikan.'}</h3><p>Anda mendapat <b>${state.score} / ${quiz.length}</b>. Semak semula jawapan yang salah dan cuba lagi apabila bersedia.</p><button class="outline-btn" data-action="reset-quiz">Ulang kuiz ${icon('arrow')}</button></div>`;
  const current = quiz[state.quizIndex];
  return `<div class="quiz-top"><span>SOALAN ${String(state.quizIndex + 1).padStart(2,'0')} / ${quiz.length}</span><div class="quiz-progress">${quiz.map((_, index) => `<i class="${index < state.quizIndex ? 'done' : index === state.quizIndex ? 'current' : ''}"></i>`).join('')}</div></div><h3>${current.q}</h3><div class="quiz-options">${current.options.map((option, index) => `<button class="quiz-option ${state.answered ? (index === current.answer ? 'correct' : index === state.selectedAnswer ? 'wrong' : '') : ''}" data-answer="${index}" ${state.answered ? 'disabled' : ''}><span>${String.fromCharCode(65 + index)}</span>${option}${state.answered && index === current.answer ? icon('check') : ''}</button>`).join('')}</div>${state.answered ? `<div class="quiz-feedback ${state.selectedAnswer === current.answer ? 'good' : 'needs-work'}"><b>${state.selectedAnswer === current.answer ? 'Tepat!' : 'Cuba semula idea ini.'}</b><span>${current.why}</span><button class="text-btn" data-action="next-quiz">${state.quizIndex === quiz.length - 1 ? 'Lihat keputusan' : 'Soalan seterusnya'} ${icon('arrow')}</button></div>` : '<p class="quiz-hint">Pilih satu jawapan untuk membuka maklum balas.</p>'}`;
}

function renderGuidance() {
  return `<section class="page-pad inner-page"><div class="page-intro"><div class="eyebrow-line"><span>06</span><span class="line"></span><span>PERANAN & ETIKA</span></div><h1>Jadikan ruang ini<br><em>milik bersama.</em></h1><p>Panduan ringkas untuk guru dan murid menggunakan laman web dalam mod blended, hibrid atau pembelajaran kendiri tidak segerak.</p></div><div class="guidance-grid"><article class="guide-panel teacher"><div class="guide-head"><span class="guide-icon">G</span><div><span class="tag">UNTUK GURU</span><h2>Pantau. Bimbing. Tambah baik.</h2></div></div><ol><li><b>Mulakan dengan taklimat.</b><span>Terangkan objektif dan biarkan murid memilih laluan Bakawali, Sakura atau Akasia.</span></li><li><b>Perhatikan bukti.</b><span>Gunakan senarai semak semasa murid membaca, menaakul dan berkongsi ramalan.</span></li><li><b>Beri maklum balas segera.</b><span>Rujuk jawapan kuiz, hasil rumusan dan exit ticket untuk merancang sokongan seterusnya.</span></li></ol><button class="outline-btn" data-action="open-checklist">Buka panel senarai semak ${icon('arrow')}</button></article><article class="guide-panel learner"><div class="guide-head"><span class="guide-icon">M</span><div><span class="tag">UNTUK MURID</span><h2>Pilih. Teroka. Kongsi.</h2></div></div><ol><li><b>Ikut urutan checkpoint.</b><span>Mulakan di Segmen 1, baca bahan dalam Segmen 2 dan selesaikan kuiz di Segmen 3.</span></li><li><b>Gunakan sokongan.</b><span>Klik kata kunci, kad soalan atau audio apabila anda memerlukan bimbingan.</span></li><li><b>Jaga jejak digital.</b><span>Hargai hasil rakan, semak sumber dan jangan kongsi maklumat peribadi.</span></li></ol><div class="guide-note">Laluan murid bermula di Set Induksi dan bergerak mengikut checkpoint pada menu utama.</div></article></div><div class="ethics-band"><div><span class="tag">ETIKA DIGITAL</span><h2>Belajar dengan rasa ingin tahu.<br>Kongsi dengan rasa hormat.</h2></div><div class="ethics-points"><span>${icon('check')} Sumber berlesen</span><span>${icon('check')} Data murid dilindungi</span><span>${icon('check')} Maklum balas berhemah</span></div></div><div class="cc-footer"><span class="cc-badge">CC</span><p>Kandungan pembelajaran asal laman ini dikongsi di bawah lesen <b>CC BY-NC-SA 4.0</b>. Bahan pihak ketiga digunakan untuk tujuan pendidikan dan perlu dirujuk mengikut lesen asal.</p></div></section>`;
}

function escapeChatText(value) {
  return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[character]));
}
function renderChatbot() {
  const messages = state.chatMessages.map(message => `<div class="chat-message ${message.role}"><span>${message.role === 'assistant' ? 'AI' : 'ANDA'}</span><p>${escapeChatText(message.content).replace(/\n/g, '<br>')}</p></div>`).join('');
  const suggestions = ['Apakah isi penting cerita Adam?', 'Bantu saya bina satu ramalan.', 'Adakah pekerjaan angkasawan memerlukan tenaga tinggi?'];
  return `<aside class="chatbot ${state.chatOpen ? 'open' : ''}" aria-label="Rakan ChatBot AI"><button class="chatbot-launcher" data-action="toggle-chat" aria-expanded="${state.chatOpen}"><span class="chatbot-orbit">◎</span><span>Rakan ChatBot AI</span><b>${state.chatOpen ? '×' : '↗'}</b></button>${state.chatOpen ? `<div class="chatbot-panel"><div class="chatbot-head"><div><span class="tag">RAKAN PEMBELAJARAN</span><h2>Tanya apa sahaja.</h2></div><button class="chat-close" data-action="toggle-chat" aria-label="Tutup chatbot">×</button></div><div class="chatbot-note">Jawapan dalam Bahasa Melayu yang mesra murid Tahun 6. AI boleh membantu bahan RPH dan soalan pengetahuan umum.</div><div class="chat-messages">${messages}${state.chatBusy ? '<div class="chat-message assistant"><span>AI</span><p class="chat-typing">Sedang berfikir…</p></div>' : ''}</div><div class="chat-suggestions">${suggestions.map(suggestion => `<button type="button" data-chat-suggestion="${escapeChatText(suggestion)}">${escapeChatText(suggestion)}</button>`).join('')}</div><form class="chat-form" id="chat-form"><textarea name="message" maxlength="1500" placeholder="Tulis soalan anda…" required ${state.chatBusy ? 'disabled' : ''}></textarea><button class="primary-btn" type="submit" ${state.chatBusy ? 'disabled' : ''}>Hantar ${icon('arrow')}</button></form><small class="chatbot-privacy">Jangan masukkan nama penuh, kata laluan atau maklumat peribadi.</small></div>` : ''}</aside>`;
}
function renderFooter() {
  return `<footer class="site-footer page-pad"><div class="footer-brand"><span class="brand-mark"><span></span><i></i></span><div><b>TEROKAI ANGKASA KITA</b><small>Persekitaran pembelajaran digital Bahasa Melayu Tahun 6</small></div></div><div class="footer-links"><span>SK 2.2</span><span>SP 2.2.1</span><span>ASSURE</span><span>CC BY-NC-SA 4.0</span></div></footer>`;
}

function toast(message) {
  state.toast = message;
  render();
  window.setTimeout(() => { state.toast = ''; render(); }, 2600);
}

function bindEvents() {
  document.querySelectorAll('[data-nav]').forEach(button => button.addEventListener('click', () => {
    state.section = button.dataset.nav;
    state.menuOpen = false;
    if (button.dataset.group) state.activeGroup = button.dataset.group;
    window.scrollTo({ top: 0, behavior: 'smooth' });
    render();
  }));
  document.querySelectorAll('[data-group]').forEach(button => button.addEventListener('click', () => {
    state.activeGroup = button.dataset.group;
    render();
  }));
  document.querySelectorAll('[data-object]').forEach(button => button.addEventListener('click', () => {
    state.explorer = button.dataset.object;
    render();
  }));
  document.querySelectorAll('[data-video-answer]').forEach(button => button.addEventListener('click', () => {
    state.videoAnswered = true;
    render();
  }));
  document.querySelectorAll('[data-answer]').forEach(button => button.addEventListener('click', () => {
    const current = quiz[state.quizIndex];
    state.selectedAnswer = Number(button.dataset.answer);
    state.answered = true;
    if (state.selectedAnswer === current.answer) state.score += 1;
    render();
  }));
  document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => handleAction(button.dataset.action, button.dataset)));
  document.querySelectorAll('.idea-form').forEach(form => form.addEventListener('submit', event => { event.preventDefault(); state.promptResponses[form.dataset.prompt] = form.querySelector('textarea').value; toast('Idea anda telah disimpan.'); }));
  document.querySelectorAll('.group-response-form').forEach(form => form.addEventListener('submit', event => { event.preventDefault(); state.groupResponses[form.dataset.groupResponse] = form.querySelector('textarea').value; toast('Respons kumpulan telah disimpan.'); }));
  const form = document.querySelector('#exit-form');
  if (form) form.addEventListener('submit', event => {
    event.preventDefault();
    state.exitSaved = true;
    toast('Refleksi berjaya dihantar kepada guru.');
  });
  document.querySelectorAll('[data-check]').forEach(input => input.addEventListener('change', () => {
    state.checklist[input.dataset.check] = input.checked;
    renderChecklistModal();
  }));
  document.querySelectorAll('[data-chat-suggestion]').forEach(button => button.addEventListener('click', () => sendChatMessage(button.dataset.chatSuggestion)));
  const chatForm = document.querySelector('#chat-form');
  if (chatForm) chatForm.addEventListener('submit', event => { event.preventDefault(); const input = chatForm.querySelector('textarea'); sendChatMessage(input.value); });
}

async function sendChatMessage(rawMessage) {
  const message = String(rawMessage || '').trim();
  if (!message || state.chatBusy) return;
  state.chatMessages.push({ role: 'user', content: message });
  state.chatBusy = true;
  state.chatOpen = true;
  render();
  try {
    const response = await fetch('/.netlify/functions/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message, history: state.chatMessages.slice(-8) }) });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || 'Permintaan chatbot gagal.');
    state.chatMessages.push({ role: 'assistant', content: payload.reply || 'Maaf, saya belum dapat menjawab soalan itu.' });
  } catch (error) {
    state.chatMessages.push({ role: 'assistant', content: 'Maaf, chatbot belum dapat disambungkan sekarang. Pastikan Netlify Function dan OPENAI_API_KEY telah dikonfigurasikan.' });
  } finally {
    state.chatBusy = false;
    render();
    setTimeout(() => document.querySelector('.chat-messages')?.scrollTo({ top: 99999, behavior: 'smooth' }), 0);
  }
}
function handleAction(action, data) {
  if (action === 'toggle-chat') { state.chatOpen = !state.chatOpen; render(); return; }
  if (action === 'toggle-menu') { state.menuOpen = !state.menuOpen; render(); setTimeout(() => document.querySelector('#main-nav')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 0); }
  if (action === 'play-intro') toast('Pengenalan dimainkan — ikut lirik dan bayangkan diri anda sebagai angkasawan.');
  if (action === 'reveal') toast(data.message);
  if (action === 'book-open') toast('Buku cerita dibuka — halaman 1: Impian Adam bermula apabila dia memandang langit malam.');
  if (action === 'save-prediction') toast('Ramalan disimpan. Jangan lupa berikan sebab yang menyokongnya.');
  if (action === 'open-tool') toast(`${data.tool}: pautan aktiviti simulasi tersedia untuk digunakan dalam kelas.`);
  if (action === 'next-video') { state.videoStep = state.videoStep === 2 ? 0 : state.videoStep + 1; state.videoAnswered = false; render(); setTimeout(() => document.querySelector('.generated-video')?.play().catch(() => {}), 0); }
  if (action === 'next-quiz') { state.quizIndex += 1; state.answered = false; state.selectedAnswer = null; render(); }
  if (action === 'reset-quiz') { state.quizIndex = 0; state.score = 0; state.answered = false; state.selectedAnswer = null; render(); }
  if (action === 'open-exit') { state.section = 'segment3'; render(); setTimeout(() => document.querySelector('.exit-ticket')?.scrollIntoView({ behavior: 'smooth' }), 50); }
  if (action === 'open-checklist') renderChecklistModal();
}

function renderChecklistModal() {
  const existing = document.querySelector('.modal-backdrop');
  if (existing) existing.remove();
  document.body.insertAdjacentHTML('beforeend', `<div class="modal-backdrop"><div class="checklist-modal"><button class="modal-close" data-action="close-modal">×</button><span class="tag">INSTRUMEN PENTAKSIRAN PROSES</span><h2>Senarai semak guru</h2><p>Tanda semasa murid membaca dan menaakul. Kemajuan disimpan dalam sesi ini.</p><div class="check-items">${checklistItems.map((item, index) => `<label><input type="checkbox" data-check="${index}" ${state.checklist[index] ? 'checked' : ''}><span>${item}</span></label>`).join('')}</div><div class="check-progress"><span>${Object.values(state.checklist).filter(Boolean).length} / ${checklistItems.length} indikator diperhatikan</span><div><i style="width:${(Object.values(state.checklist).filter(Boolean).length / checklistItems.length) * 100}%"></i></div></div><button class="primary-btn" data-action="close-modal">Simpan catatan ${icon('arrow')}</button></div></div>`);
  document.querySelectorAll('[data-check]').forEach(input => input.addEventListener('change', () => { state.checklist[input.dataset.check] = input.checked; renderChecklistModal(); }));
  document.querySelectorAll('[data-action="close-modal"]').forEach(button => button.addEventListener('click', () => document.querySelector('.modal-backdrop')?.remove()));
}

render();
