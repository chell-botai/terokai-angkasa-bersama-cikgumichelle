# Terokai Angkasa Kita — build outcomes

- [ ] Home page introduces the RPH, ASSURE model, SK 2.2, SP 2.2.1, objective, success criteria, delivery mode and Creative Commons notice.
- [ ] ASSURE navigation presents all six phases in Malay.
- [ ] Segmen 1 provides space-themed induction, teacher context, sing-along prompt and formative questions.
- [ ] Segmen 2 provides digital-story exploration, AR-style object exploration, prediction prompts and meaning-making activities.
- [ ] Bakawali, Sakura and Akasia have distinct differentiated workspaces, scaffolds and success criteria.
- [ ] Teacher panel includes an observation checklist and feedback guidance.
- [ ] Segmen 3 supports enrichment, remediation and differentiated next steps.
- [ ] Gamified assessment provides immediate feedback, progress and visible score.
- [ ] Exit ticket supports self-reflection and feedback on digital media.
- [ ] Teacher/learner guidance covers blended, hybrid, self-paced and responsible digital participation.
