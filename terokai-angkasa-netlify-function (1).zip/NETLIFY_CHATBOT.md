# Konfigurasi Rakan ChatBot AI di Netlify

Chatbot telah ditambah sebagai panel terapung pada laman. Ia menggunakan Netlify Function `netlify/functions/chat.mjs`, jadi API key tidak dimasukkan ke dalam JavaScript awam.

## Environment Variables di Netlify

Di Netlify: **Site configuration → Environment variables → Add a variable**

- `OPENAI_API_KEY`: API key OpenAI anda
- `OPENAI_MODEL`: pilihan, lalai `gpt-4o-mini`
- `OPENAI_API_BASE`: pilihan, lalai `https://api.openai.com/v1`

Selepas menambah pemboleh ubah, lakukan deploy semula. Jangan masukkan API key ke dalam `src/main.js`, `dist/` atau fail ZIP yang dihantar kepada orang lain.
