export default {
  logoUrl: "https://www.svgrepo.com/show/530631/rocket.svg"
};
